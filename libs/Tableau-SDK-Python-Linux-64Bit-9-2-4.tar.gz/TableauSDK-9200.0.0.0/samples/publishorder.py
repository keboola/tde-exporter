# -----------------------------------------------------------------------------
#
# This file is the copyrighted property of Tableau Software and is protected
# by registered patents and other applicable U.S. and international laws and
# regulations.
#
# Unlicensed use of the contents of this file is prohibited. Please refer to
# the NOTICES.txt file for further details.
#
# -----------------------------------------------------------------------------

from tableausdk import *
from tableausdk.Server import *

try:
    # Initialize Tableau Server API
    ServerAPI.initialize()

    # Create the server connection object
    serverConnection = ServerConnection()

    # Connect to the server
    serverConnection.connect('http://localhost', 'username', 'password', 'siteID');

    # Publish order-py.tde to the server under the default project with name Order-py
    serverConnection.publishExtract('order-py.tde', 'default', 'Order-py', False);

    # Disconnect from the server
    serverConnection.disconnect();

    # Destroy the server connection object
    serverConnection.close();

    # Clean up Tableau Server API
    ServerAPI.cleanup();

except TableauException, e:
    # Handle the exception depending on the type of exception received

    errorMessage = "Error: "

    if e.errorCode == Result.INTERNAL_ERROR:
        errorMessage += "INTERNAL_ERROR - Could not parse the response from the server."

    elif e.errorCode == Result.INVALID_ARGUMENT:
        errorMessage += "INVALID_ARGUMENT - " + e.message

    elif e.errorCode == Result.CURL_ERROR:
        errorMessage += "CURL_ERROR - " + e.message

    elif e.errorCode == Result.SERVER_ERROR:
        errorMessage += "SERVER_ERROR - " + e.message

    elif e.errorCode == Result.NOT_AUTHENTICATED:
        errorMessage += "NOT_AUTHENTICATED - " + e.message

    elif e.errorCode == Result.BAD_PAYLOAD:
        errorMessage += "BAD_PAYLOAD - Unknown response from the server. Make sure this version of Tableau API is compatible with your server."

    elif e.errorCode == Result.INIT_ERROR:
        errorMessage += "INIT_ERROR - " + e.message

    else:
        errorMessage += "An unknown error occured."

    print errorMessage

