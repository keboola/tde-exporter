Tableau Data Extract API

Create extract files for use with Tableau's fast Data Engine.

================
= Requirements =
================
(*) Python 2.x with x >= 6
(*) The correct flavor (platform + architecture) version of this package.

================
= Installation = 
================
(1) python setup.py build
(2*) python setup.py install

[*] Run as root on POSIX platforms
