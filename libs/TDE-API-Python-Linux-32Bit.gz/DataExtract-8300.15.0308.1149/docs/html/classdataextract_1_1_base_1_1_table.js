var classdataextract_1_1_base_1_1_table =
[
    [ "__init__", "classdataextract_1_1_base_1_1_table.html#ad43a27025c873eb892f076e27edbc2d3", null ],
    [ "getTableDefinition", "classdataextract_1_1_base_1_1_table.html#a4105b94141f5a2dcee9c52804cd2a32f", null ],
    [ "insert", "classdataextract_1_1_base_1_1_table.html#ace563177455e7d54566679f684320a0b", null ]
];