var namespaces =
[
    [ "dataextract", "namespacedataextract.html", "namespacedataextract" ]
];