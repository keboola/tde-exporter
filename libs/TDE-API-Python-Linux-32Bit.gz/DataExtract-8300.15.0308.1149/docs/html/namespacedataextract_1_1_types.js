var namespacedataextract_1_1_types =
[
    [ "Type", "classdataextract_1_1_types_1_1_type.html", null ],
    [ "Result", "classdataextract_1_1_types_1_1_result.html", null ],
    [ "Collation", "classdataextract_1_1_types_1_1_collation.html", null ]
];