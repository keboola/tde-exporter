var namespacedataextract_1_1_base =
[
    [ "TableDefinition", "classdataextract_1_1_base_1_1_table_definition.html", "classdataextract_1_1_base_1_1_table_definition" ],
    [ "Row", "classdataextract_1_1_base_1_1_row.html", "classdataextract_1_1_base_1_1_row" ],
    [ "Table", "classdataextract_1_1_base_1_1_table.html", "classdataextract_1_1_base_1_1_table" ],
    [ "Extract", "classdataextract_1_1_base_1_1_extract.html", "classdataextract_1_1_base_1_1_extract" ]
];