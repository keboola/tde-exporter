var searchData=
[
  ['collation',['Collation',['../classdataextract_1_1_types_1_1_collation.html',1,'dataextract::Types']]]
];
