var searchData=
[
  ['network_5ferror',['NETWORK_ERROR',['../classdataextract_1_1_types_1_1_result.html#af186cceba1dba868e9c01aa2cb29b39f',1,'dataextract::Types::Result']]],
  ['nl_5fnl',['NL_NL',['../classdataextract_1_1_types_1_1_collation.html#a68e2c1159e847b5215fca2dc07de3f67',1,'dataextract::Types::Collation']]],
  ['nn',['NN',['../classdataextract_1_1_types_1_1_collation.html#a7820581673466b12287ee4676f0f77a1',1,'dataextract::Types::Collation']]],
  ['no_5fsuch_5fdatabase',['NO_SUCH_DATABASE',['../classdataextract_1_1_types_1_1_result.html#aa18d3d9224ae53478359bf46734151f9',1,'dataextract::Types::Result']]],
  ['null_5fargument',['NULL_ARGUMENT',['../classdataextract_1_1_types_1_1_result.html#a973b5bf9d133d6231fb74f8d09b472f6',1,'dataextract::Types::Result']]]
];
