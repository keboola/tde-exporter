var searchData=
[
  ['uk',['UK',['../classdataextract_1_1_types_1_1_collation.html#acc6a6bfa306c2a9d073f0b0e9b567f1d',1,'dataextract::Types::Collation']]],
  ['unicode_5fstring',['UNICODE_STRING',['../classdataextract_1_1_types_1_1_type.html#a825a953dfb0130a50d23d205aff3f975',1,'dataextract::Types::Type']]],
  ['unknown_5ferror',['UNKNOWN_ERROR',['../classdataextract_1_1_types_1_1_result.html#aede076c843924c89a8d4bec8ee2aed3f',1,'dataextract::Types::Result']]],
  ['usage_5ferror',['USAGE_ERROR',['../classdataextract_1_1_types_1_1_result.html#a201f480d8abd6dd165c3e036ce65daa5',1,'dataextract::Types::Result']]]
];
