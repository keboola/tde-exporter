var searchData=
[
  ['sl',['SL',['../classdataextract_1_1_types_1_1_collation.html#ab7e01334470a398a25e5c2c179b1c395',1,'dataextract::Types::Collation']]],
  ['success',['SUCCESS',['../classdataextract_1_1_types_1_1_result.html#ad13074d45cf6af1c0235d528d562f871',1,'dataextract::Types::Result']]],
  ['sv_5ffi',['SV_FI',['../classdataextract_1_1_types_1_1_collation.html#afc010155a4099d05b72a953e6f569e46',1,'dataextract::Types::Collation']]],
  ['sv_5fse',['SV_SE',['../classdataextract_1_1_types_1_1_collation.html#a410b86a16c46e9ca3306ad9d3888ce88',1,'dataextract::Types::Collation']]]
];
