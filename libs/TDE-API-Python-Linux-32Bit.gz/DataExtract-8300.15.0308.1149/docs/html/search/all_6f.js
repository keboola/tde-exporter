var searchData=
[
  ['opentable',['openTable',['../classdataextract_1_1_base_1_1_extract.html#a4e7a00fcca4781167b78ea1a7817966f',1,'dataextract::Base::Extract']]],
  ['out_5fof_5fmemory',['OUT_OF_MEMORY',['../classdataextract_1_1_types_1_1_result.html#adbbf99879c50b969b8544939fe0cf127',1,'dataextract::Types::Result']]]
];
