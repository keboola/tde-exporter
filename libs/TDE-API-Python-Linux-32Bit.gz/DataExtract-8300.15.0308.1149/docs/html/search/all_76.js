var searchData=
[
  ['vi',['VI',['../classdataextract_1_1_types_1_1_collation.html#af595ce3c3ebd54bcd99ec0564aa71775',1,'dataextract::Types::Collation']]]
];
