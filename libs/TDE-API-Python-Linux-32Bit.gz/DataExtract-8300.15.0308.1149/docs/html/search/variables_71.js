var searchData=
[
  ['query_5ferror',['QUERY_ERROR',['../classdataextract_1_1_types_1_1_result.html#a538dc4f7f10e553e708a8eeb70c54569',1,'dataextract::Types::Result']]]
];
