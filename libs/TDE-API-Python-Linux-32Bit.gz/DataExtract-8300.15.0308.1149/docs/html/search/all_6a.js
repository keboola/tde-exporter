var searchData=
[
  ['ja',['JA',['../classdataextract_1_1_types_1_1_collation.html#aece29abb05ad418cb6f172378ae844d6',1,'dataextract::Types::Collation']]],
  ['ja_5fjis',['JA_JIS',['../classdataextract_1_1_types_1_1_collation.html#af6d779c12c7165a1fe05588b994453f5',1,'dataextract::Types::Collation']]]
];
