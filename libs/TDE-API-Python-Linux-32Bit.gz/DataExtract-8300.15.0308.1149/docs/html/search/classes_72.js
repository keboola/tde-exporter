var searchData=
[
  ['result',['Result',['../classdataextract_1_1_types_1_1_result.html',1,'dataextract::Types']]],
  ['row',['Row',['../classdataextract_1_1_base_1_1_row.html',1,'dataextract::Base']]]
];
