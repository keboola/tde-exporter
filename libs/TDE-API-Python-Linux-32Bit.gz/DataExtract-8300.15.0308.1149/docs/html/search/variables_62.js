var searchData=
[
  ['bad_5fhandle',['BAD_HANDLE',['../classdataextract_1_1_types_1_1_result.html#aa45306fc7707469aa3e25467762eec5a',1,'dataextract::Types::Result']]],
  ['bad_5findex',['BAD_INDEX',['../classdataextract_1_1_types_1_1_result.html#a2a4c4c61c8b805bdca6d1111e3f77572',1,'dataextract::Types::Result']]],
  ['binary',['BINARY',['../classdataextract_1_1_types_1_1_collation.html#a4b0b874bc8995ed6716e7d681617c85b',1,'dataextract::Types::Collation']]],
  ['boolean',['BOOLEAN',['../classdataextract_1_1_types_1_1_type.html#a0cd1030f85dcfdb16d568a16df7ff99a',1,'dataextract::Types::Type']]]
];
