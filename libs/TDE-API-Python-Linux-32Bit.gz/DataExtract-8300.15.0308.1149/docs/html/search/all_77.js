var searchData=
[
  ['wrong_5ftype',['WRONG_TYPE',['../classdataextract_1_1_types_1_1_result.html#a270d3998a8f46c28184de65aaf779f58',1,'dataextract::Types::Result']]]
];
