var searchData=
[
  ['fi',['FI',['../classdataextract_1_1_types_1_1_collation.html#a56322e13e8f90d04022fe665655dff91',1,'dataextract::Types::Collation']]],
  ['file_5fexists',['FILE_EXISTS',['../classdataextract_1_1_types_1_1_result.html#a680263e8bfcffe794ee17e1851408de1',1,'dataextract::Types::Result']]],
  ['file_5fnot_5ffound',['FILE_NOT_FOUND',['../classdataextract_1_1_types_1_1_result.html#aa85cd09053f8d46db5d23e542bf6b05f',1,'dataextract::Types::Result']]],
  ['fisk_5ffull',['FISK_FULL',['../classdataextract_1_1_types_1_1_result.html#a3adfb81ab957502c88f749b1fc343685',1,'dataextract::Types::Result']]],
  ['fr_5fca',['FR_CA',['../classdataextract_1_1_types_1_1_collation.html#a87027c73c4dc6f0dd0e7ff27af0e3bb1',1,'dataextract::Types::Collation']]],
  ['fr_5ffr',['FR_FR',['../classdataextract_1_1_types_1_1_collation.html#a0986ef51634101a66072c52eac892e44',1,'dataextract::Types::Collation']]],
  ['fr_5ffr_5fci_5fai',['FR_FR_CI_AI',['../classdataextract_1_1_types_1_1_collation.html#a715f6cfd2366c6719f7047270670c1f5',1,'dataextract::Types::Collation']]]
];
