var searchData=
[
  ['permission_5fdenied',['PERMISSION_DENIED',['../classdataextract_1_1_types_1_1_result.html#a1e07562b32921439c6fcab62ee0e54d8',1,'dataextract::Types::Result']]],
  ['pl',['PL',['../classdataextract_1_1_types_1_1_collation.html#aceebf50b43c2bd8814600709925ecd02',1,'dataextract::Types::Collation']]],
  ['protocol_5ferror',['PROTOCOL_ERROR',['../classdataextract_1_1_types_1_1_result.html#a2a7656bbea9d16d956c7afb84647029f',1,'dataextract::Types::Result']]],
  ['pt_5fbr',['PT_BR',['../classdataextract_1_1_types_1_1_collation.html#a0336ca841051cf5341271e2fcf76d0ff',1,'dataextract::Types::Collation']]],
  ['pt_5fbr_5fci_5fai',['PT_BR_CI_AI',['../classdataextract_1_1_types_1_1_collation.html#a6be04d5469bdcabe041fb72e26926857',1,'dataextract::Types::Collation']]],
  ['pt_5fpt',['PT_PT',['../classdataextract_1_1_types_1_1_collation.html#af2a6db46d604b138efe3a0aa29bba47a',1,'dataextract::Types::Collation']]]
];
