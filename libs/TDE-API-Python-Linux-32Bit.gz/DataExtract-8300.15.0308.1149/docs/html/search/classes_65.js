var searchData=
[
  ['extract',['Extract',['../classdataextract_1_1_base_1_1_extract.html',1,'dataextract::Base']]]
];
