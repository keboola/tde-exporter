var searchData=
[
  ['close',['close',['../classdataextract_1_1_base_1_1_table_definition.html#af9e0dfb0d16832d74e9cb31c7cad86d2',1,'dataextract.Base.TableDefinition.close()'],['../classdataextract_1_1_base_1_1_row.html#a972e9b06bc72d8f2d0c90fc23104b270',1,'dataextract.Base.Row.close()'],['../classdataextract_1_1_base_1_1_extract.html#ad116fc2ab0d104706fb7a1d8ba6a3e9f',1,'dataextract.Base.Extract.close()']]]
];
