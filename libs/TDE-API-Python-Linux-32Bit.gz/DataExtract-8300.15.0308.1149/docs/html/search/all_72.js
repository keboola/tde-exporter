var searchData=
[
  ['result',['Result',['../classdataextract_1_1_types_1_1_result.html',1,'dataextract::Types']]],
  ['root',['ROOT',['../classdataextract_1_1_types_1_1_collation.html#a3e0f5b4404501e2482821c7bbfacb66b',1,'dataextract::Types::Collation']]],
  ['row',['Row',['../classdataextract_1_1_base_1_1_row.html',1,'dataextract::Base']]],
  ['ru',['RU',['../classdataextract_1_1_types_1_1_collation.html#a30cf5fef0f8311999046394c5c632cde',1,'dataextract::Types::Collation']]]
];
