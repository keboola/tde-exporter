var searchData=
[
  ['zh_5fhans_5fcn',['ZH_HANS_CN',['../classdataextract_1_1_types_1_1_collation.html#a8dc9795100f930eb8e823ab4cc5aa686',1,'dataextract::Types::Collation']]],
  ['zh_5fhant_5ftw',['ZH_HANT_TW',['../classdataextract_1_1_types_1_1_collation.html#a5753dfa2dde0df647f698382e602bdd3',1,'dataextract::Types::Collation']]]
];
