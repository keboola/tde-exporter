var classdataextract_1_1_base_1_1_table_definition =
[
    [ "__init__", "classdataextract_1_1_base_1_1_table_definition.html#aa1ccce1713fac1706820850c1e54f1b6", null ],
    [ "__del__", "classdataextract_1_1_base_1_1_table_definition.html#a95bfc97142cc62386f582cdb831b7b61", null ],
    [ "addColumn", "classdataextract_1_1_base_1_1_table_definition.html#a9884c57ba04ac06431462a6beab694cd", null ],
    [ "addColumnWithCollation", "classdataextract_1_1_base_1_1_table_definition.html#a9c6a56f3cd76839f818eb17c77b65604", null ],
    [ "close", "classdataextract_1_1_base_1_1_table_definition.html#af9e0dfb0d16832d74e9cb31c7cad86d2", null ],
    [ "getColumnCollation", "classdataextract_1_1_base_1_1_table_definition.html#a0f1759b9098278bcd6385f23d46932a6", null ],
    [ "getColumnCount", "classdataextract_1_1_base_1_1_table_definition.html#af4dd1791984e526ab20f2e08f86dd447", null ],
    [ "getColumnName", "classdataextract_1_1_base_1_1_table_definition.html#a96555271fafda7541ca50a23b8ac7d3b", null ],
    [ "getColumnType", "classdataextract_1_1_base_1_1_table_definition.html#a9bc6214c6199362c8780f70b71a40a92", null ],
    [ "getDefaultCollation", "classdataextract_1_1_base_1_1_table_definition.html#a6f6a15a937276882c61ef03e0047b124", null ],
    [ "setDefaultCollation", "classdataextract_1_1_base_1_1_table_definition.html#a098dc6e287cf4eac0f5e5d0a7277098c", null ]
];