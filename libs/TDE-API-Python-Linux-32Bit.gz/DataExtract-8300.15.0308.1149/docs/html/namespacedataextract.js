var namespacedataextract =
[
    [ "Base", "namespacedataextract_1_1_base.html", "namespacedataextract_1_1_base" ],
    [ "Exceptions", "namespacedataextract_1_1_exceptions.html", "namespacedataextract_1_1_exceptions" ],
    [ "Libs", "namespacedataextract_1_1_libs.html", "namespacedataextract_1_1_libs" ],
    [ "StringUtils", "namespacedataextract_1_1_string_utils.html", null ],
    [ "Types", "namespacedataextract_1_1_types.html", "namespacedataextract_1_1_types" ]
];